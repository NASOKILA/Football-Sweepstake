﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="The Contact Group">2018</copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace CG.Recruitment.Sweepstake.DataStore
{
    using System;

    public class Competitor
    {
        public Guid Id { get; set; }

        public Guid CompetitionId { get; set; }

        public string Name { get; set; }
    }
}