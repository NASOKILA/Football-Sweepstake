﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="The Contact Group">2018</copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace CG.Recruitment.Sweepstake.DataStore
{
    using System;

    public class Gambler
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}