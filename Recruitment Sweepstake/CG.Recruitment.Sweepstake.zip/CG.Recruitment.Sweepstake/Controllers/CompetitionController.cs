﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="The Contact Group">2018</copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace CG.Recruitment.Sweepstake.Controllers
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CG.Recruitment.Sweepstake.DataStore;
    using CG.Recruitment.Sweepstake.Library.Competition;
    using Microsoft.AspNetCore.Mvc;

    [Route("api/Competitions")]
    public class CompetitionController : Controller
    {
        [HttpGet]
        public async Task<IEnumerable<Competition>> Competitions()
        {
            var handler = new CompetitionQueryHandler();
            return await handler.HandleAsync(new CompetitionQuery());
        }

        [HttpPost]
        public async Task<OkObjectResult> Competition([FromBody] CreateCompetitionCommand command)
        {
            var handler = new CreateCompetitionHandler();
            await handler.HandleAsync(command);
            return this.Ok(new { message = "Competition created."});
        }
    }
}