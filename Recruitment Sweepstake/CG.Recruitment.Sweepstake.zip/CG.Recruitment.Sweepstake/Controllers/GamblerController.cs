﻿namespace CG.Recruitment.Sweepstake.Controllers
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using CG.Recruitment.Sweepstake.DataStore;
    using CG.Recruitment.Sweepstake.Library.Gambler;
    using Microsoft.AspNetCore.Mvc;
    [Route("api/Gamblers")]
    public class GamblerController : Controller
    {
        [HttpGet]
        public async Task<IEnumerable<Gambler>> Gamblers(string name)
        {
            return await new GamblerQueryHandler().HandleAsync(new GamblerQuery
            {
                Name = name
            });
        }

        [HttpPost]
        public async Task<OkObjectResult> Gambler([FromBody] CreateGamblerCommand command)
        {
            var handler = new CreateGamblerHandler();
            await handler.HandleAsync(command);
            return this.Ok(new { message = "Gambler created." });
        }
    }
}
