﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="The Contact Group">2018</copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace CG.Recruitment.Sweepstake.Library
{
    public class Constants
    {
        public const string ConnectionString =
            "Server=(localdb)\\mssqllocaldb;Database=Sweepstake;Trusted_Connection=True;MultipleActiveResultSets=true";
    }
}