﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright company="The Contact Group">2018</copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace CG.Recruitment.Sweepstake.Library.Gambler
{
    using System;

    public class GamblerQuery
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}